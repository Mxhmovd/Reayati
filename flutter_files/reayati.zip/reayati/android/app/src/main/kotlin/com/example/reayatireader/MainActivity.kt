package com.example.reayatireader

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
