from lib.blood_test_db.firebase_admin_setup import initialize_firebase

db = initialize_firebase()

blood_tests = [
    {"testName": "MIDn", "description": "Mid-range Cells Number", "units": "thousand/uL", "normalRangeMin": 0.2, "normalRangeMax": 0.8},
    {"testName": "NEUTn", "description": "Neutrophils Number", "units": "thousand/uL", "normalRangeMin": 2.0, "normalRangeMax": 7.0},
    {"testName": "RBC", "description": "Red Blood Cells", "units": "million/uL", "normalRangeMinMale": 4.7, "normalRangeMaxMale": 6.1, "normalRangeMinFemale": 4.2, "normalRangeMaxFemale": 5.4},
    {"testName": "HCT", "description": "Hematocrit", "units": "%", "normalRangeMinMale": 40, "normalRangeMaxMale": 52, "normalRangeMinFemale": 36, "normalRangeMaxFemale": 48},
    {"testName": "MCV", "description": "Mean Corpuscular Volume", "units": "femtoliters", "normalRangeMin": 80, "normalRangeMax": 96},
    {"testName": "MCH", "description": "Mean Corpuscular Hemoglobin", "units": "picograms/cell", "normalRangeMin": 27, "normalRangeMax": 33},
    {"testName": "MCHC", "description": "Mean Corpuscular Hemoglobin Concentration", "units": "%", "normalRangeMin": 33, "normalRangeMax": 36},
    {"testName": "RDWSD", "description": "Red Cell Distribution Width-Standard Deviation", "units": "%", "normalRangeMin": 11, "normalRangeMax": 15},
    {"testName": "RDWCV", "description": "Red Cell Distribution Width-Coefficient of Variation", "units": "%", "normalRangeMin": 11.5, "normalRangeMax": 14.5},
    {"testName": "PLT", "description": "Platelets", "units": "platelets/uL", "normalRangeMin": 150000, "normalRangeMax": 450000},
    {"testName": "MPV", "description": "Mean Platelet Volume", "units": "femtoliters", "normalRangeMin": 7.5, "normalRangeMax": 11.5},
    {"testName": "PDW", "description": "Platelet Distribution Width", "units": "%", "normalRangeMin": 9, "normalRangeMax": 17},
    {"testName": "PCT", "description": "Plateletcrit", "units": "%", "normalRangeMin": 0.22, "normalRangeMax": 0.24},
    {"testName": "PLCR", "description": "Platelet Larger Cell Ratio", "units": "%", "normalRangeMin": 15, "normalRangeMax": 30},
    {"testName": "Alanine Aminotransferase (ALT)", "description": "Liver enzyme", "units": "U/L", "normalRangeMin": 7, "normalRangeMax": 56},
    {"testName": "Aspartate Aminotransferase (AST)", "description": "Liver enzyme", "units": "U/L", "normalRangeMin": 10, "normalRangeMax": 40},
    {"testName": "Alkaline Phosphatase (ALP)", "description": "Liver enzyme", "units": "U/L", "normalRangeMin": 44, "normalRangeMax": 147},
    {"testName": "Gamma-Glutamyl Transferase (GGT)", "description": "Liver enzyme", "units": "U/L", "normalRangeMinMale": 9, "normalRangeMaxMale": 48, "normalRangeMinFemale": 7, "normalRangeMaxFemale": 32},
    {"testName": "Bilirubin", "description": "Bile pigment level", "units": "mg/dL", "normalRangeMin": 0.3, "normalRangeMax": 1.9},
    {"testName": "Albumin", "description": "Blood protein", "units": "g/dL", "normalRangeMin": 3.4, "normalRangeMax": 5.4},
    {"testName": "Total Protein", "description": "Blood protein level", "units": "g/dL", "normalRangeMin": 6.3, "normalRangeMax": 7.9},
    {"testName": "Lactate Dehydrogenase (LDH)", "description": "Enzyme level", "units": "U/L", "normalRangeMin": 122, "normalRangeMax": 222},
    {"testName": "Fasting Blood Sugar Test", "description": "Fasting Glucose Level", "units": "mg/dL", "normal": "<100", "prediabetes": "100-125", "diabetes": "≥126"},
    {"testName": "Oral Glucose Tolerance Test (OGTT)", "description": "Glucose Level 2 hours after glucose intake", "units": "mg/dL", "normal": "<140", "prediabetes": "140-199", "diabetes": "≥200"},
    {"testName": "Random Blood Sugar Test", "description": "Blood glucose level without fasting", "units": "mg/dL", "normal": "≤140", "diabetes": "≥200"},
    {"testName": "Hemoglobin A1c Test (HbA1c)", "description": "Average blood glucose over the past 3 months", "units": "%", "normal": "<5.7", "prediabetes": "5.7-6.4", "diabetes": "≥6.5"},
    {"testName": "Fructosamine Test", "description": "Reflects average glucose levels over the past 2 to 3 weeks", "units": "mmol/L", "normalRangeMin": 0.2, "normalRangeMax": 2.3, "note": "Higher values indicate higher average glucose levels"},
    {"testName": "C-Reactive Protein (CRP)", "description": "Measures the level of CRP to assess inflammation", "units": "mg/L", "normalRangeMin": 0, "normalRangeMax": 10},
    {"testName": "Erythrocyte Sedimentation Rate (ESR)", "description": "Measures red blood cell sedimentation rate to detect inflammation", "units": "mm/hr", "normalRangeMin": 0, "normalRangeMax": 20},
    {"testName": "Thyroid-Stimulating Hormone (TSH)", "description": "Assesses thyroid function by measuring TSH levels", "units": "μIU/mL", "normalRangeMin": 0.5, "normalRangeMax": 4.5},
    {"testName": "Free T4", "description": "Measures free T4 to assess thyroid function", "units": "ng/dL", "normalRangeMin": 0.9, "normalRangeMax": 2.3},
    {"testName": "Ferritin", "description": "Measures ferritin to assess iron storage", "units": "ng/mL", "normalRangeMin": 30, "normalRangeMax": 400},
    {"testName": "Vitamin D", "description": "Measures vitamin D level", "units": "ng/mL", "normalRangeMin": 20, "normalRangeMax": 50},
    {"testName": "Vitamin B12", "description": "Measures vitamin B12 level", "units": "pg/mL", "normalRangeMin": 200, "normalRangeMax": 900},
    {"testName": "Folate", "description": "Measures folate level", "units": "ng/mL", "normalRangeMin": 2, "normalRangeMax": 20},
    {
        "testName": "Lipid Panel",
        "description": "Measures blood lipids including cholesterol and triglycerides",
        "subTests": [
            {"name": "Total Cholesterol", "units": "mg/dL", "normalRangeMin": 0, "normalRangeMax": 200},
            {"name": "LDL Cholesterol", "units": "mg/dL", "optimalRangeMax": 100},
            {"name": "HDL Cholesterol", "units": "mg/dL", "lowRangeMax": 40, "highRangeMin": 60},
            {"name": "Triglycerides", "units": "mg/dL", "normalRangeMax": 150}
        ]
    },
    {"testName": "Prostate-Specific Antigen (PSA)", "description": "Screening for prostate cancer by measuring PSA levels", "units": "ng/mL", "normalRangeMin": 0, "normalRangeMax": 4},
    {"testName": "Sodium (Na)", "description": "Essential for nerve and muscle function", "units": "mmol/L", "normalRangeMin": 135, "normalRangeMax": 145},
    {"testName": "Potassium (K)", "description": "Crucial for heart function", "units": "mmol/L", "normalRangeMin": 3.5, "normalRangeMax": 5.1},
    {"testName": "Chloride (Cl)", "description": "Helps regulate fluid balance", "units": "mmol/L", "normalRangeMin": 98, "normalRangeMax": 106},
    {"testName": "Bicarbonate (HCO3)", "description": "Important for pH balance", "units": "mmol/L", "normalRangeMin": 22, "normalRangeMax": 29},
    {"testName": "VDRL-RPR","description": "Venereal Disease Research Laboratory/Rapid Plasma Reagin Test","units": "N/A","normalRangeMin": "Negative","normalRangeMax": "Positive"},
    {"testName": "HBS antigen","description": "Hepatitis B Surface Antigen Test","units": "N/A","normalRangeMin": 0,"normalRangeMax": 1},
    {"testName": "antiHCV","description": "Hepatitis C Virus Antibody Test","units": "N/A","normalRangeMin": 0,"normalRangeMax": 1},
    {"testName": "antiHIV","description": "Human Immunodeficiency Virus Antibody Test","units": "N/A","normalRangeMin": 0,"normalRangeMax": 1},
    {"testName": "antiHBS","description": "Hepatitis B Surface Antibody Test","units": "IU/L","normalRangeMin": 0,"normalRangeMax": 10},
    {"testName": "TBIC","description": "Total Iron-Binding Capacity","units": "µg/dL","normalRangeMin": 250,"normalRangeMax": 450},
]

for test in blood_tests:
    try:
        doc_ref = db.collection('bloodTests').add(test)
        print(f"Added blood test with ID: {doc_ref[1].id}")
    except Exception as e:
        print(f"Failed to upload blood test {test['testName']}: {e}")
