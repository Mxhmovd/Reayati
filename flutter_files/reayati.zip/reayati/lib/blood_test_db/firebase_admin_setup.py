import firebase_admin
from firebase_admin import credentials, firestore
from google.cloud.firestore_v1 import Client


def initialize_firebase():
    cred_path = r'C:\Users\armou\Downloads\reayatireader-16579-firebase-adminsdk-d34kb-6131fa0810.json'

    if not firebase_admin._apps:
        cred = credentials.Certificate(cred_path)
        firebase_admin.initialize_app(cred)

    db: Client = firestore.client()
    return db
