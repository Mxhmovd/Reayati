import 'dart:convert';
import 'package:flutter/material.dart';

Widget buildMessageWidget(Map<String, dynamic> message) {
  if (message['type'] == 'image' && message['content'] != null) {
    return Container(
      padding: const EdgeInsets.all(8.0),
      margin: const EdgeInsets.symmetric(vertical: 4.0),
      child: Image.memory(
        base64Decode(message['content']),
        width: 150,
        height: 150,
        fit: BoxFit.cover,
      ),
    );
  } else if (message['type'] == 'PDF' && message['fileName'] != null) {
    // Display file name (e.g., PDF, document, etc.)
    return ListTile(
      leading: const Icon(Icons.picture_as_pdf_outlined, color: Colors.red),
      title: Text(
        message['fileName'],
        style: const TextStyle(color: Colors.white),
      ),
    );
  } else if (message['type'] == 'text' && message['content'] != null) {
    return Container(
      padding: const EdgeInsets.all(8.0),
      margin: const EdgeInsets.symmetric(vertical: 4.0),
      decoration: BoxDecoration(
        color: const Color(0xFF3C4A73),
        borderRadius: BorderRadius.circular(8.0),
      ),
      child: Text(
        message['content'],
        style: const TextStyle(color: Colors.white),
      ),
    );
  } else {
    // Handle unexpected or invalid message type
    return Container(
      padding: const EdgeInsets.all(8.0),
      margin: const EdgeInsets.symmetric(vertical: 4.0),
      decoration: BoxDecoration(
        color: Colors.red,
        borderRadius: BorderRadius.circular(8.0),
      ),
      child: const Text(
        'Invalid message type',
        style: TextStyle(color: Colors.white),
      ),
    );
  }}